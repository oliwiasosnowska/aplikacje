class Film:
    def __init__(self):
        self._tytul = ""
        self._liczbaWypozyczen = 0
    def setTytul(self, t):
        self._tytul = t
    def getTytul(self):
        return self._tytul
    def getLiczbaWypozyczen(self):
        return self._liczbaWypozyczen
    def zwiekszLiczbeWypozyczen(self):
        self._liczbaWypozyczen +=1

film1 = film()
film1.setTytul("Rambo. Pierwsza krew.")
print(film1.getTytul(), film1.getLiczbaWypozyczen())
film1.zwiekszLiczbeWypozyczen()
print(film1.getTytul(), film1.getLiczbaWypozyczen())